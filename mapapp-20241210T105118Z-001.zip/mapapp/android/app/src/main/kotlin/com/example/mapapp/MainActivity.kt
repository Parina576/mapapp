package com.example.mapapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
