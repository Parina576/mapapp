// Read at your own risk <3
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import 'package:flutter_compass/flutter_compass.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:math' as math;


class MapPage extends StatefulWidget {
  final Function(LatLng) onLocationSelected;

  const MapPage({super.key, required this.onLocationSelected});

  @override
  MapPageState createState() => MapPageState();
}

class MapPageState extends State<MapPage> {
  LatLng? _currentLocation;
  final MapController _mapController = MapController();
final List<LatLng> ewasteLocations = [
  const LatLng(27.7355, 85.3383), // Thulo Kawadi
  const LatLng(27.7000, 85.3797), // Kabadi Khana
  const LatLng(27.68737, 85.371761), // Doko Recyclers
  const LatLng(27.698530, 85.347687), // Kagaj Kabari
  const LatLng(27.673941, 85.314200), // Bandipur Kabadi
  const LatLng(27.699860, 85.28753572), // Kalu Kabadi
  const LatLng(27.70681715, 85.271935), // Arjun Kabadi Wala
  const LatLng(27.698622, 85.38617), // 3R Solutions
  const LatLng(27.707966, 85.310524), // Upcycle Nepal - Revive
];
final List<String> ewasteNames = [
  "Thulo Kawadi",
  "Kabadi Khana",
  "Doko Recyclers",
  "Kagaj Kabari",
  "Bandipur Kabadi",
  "Kalu Kabadi",
  "Arjun Kabadi Wala",
  "3R Solutions",
  "Upcycle Nepal - Revive",
];
final List<String> ewasteContacts = [
  "+977-1-1234567",
  "+977-2-7654321",
  "+977-3-1234567",
  "+977-4-9876543",
  "+977-5-6543210",
  "+977-6-9876543",
  "+977-7-2345678",
  "+977-8-8765432",
  "+977-9-7654321",
];

  final List<Marker> _markers = [];
  LatLng? _selectedLocation;
  List<LatLng> _routePoints = [];
  bool _isLoading = false;
  bool _isNavigating = false;
  double _deviceHeading = 0.0;
  bool _isEyeIconVisible = false;
  bool _isSearchIconVisible = true;
  final TextEditingController _searchController = TextEditingController();
  List<String> _filteredSuggestions = [];
  bool _isSearchBarVisible = false;

  // E-waste var -_-
  String _selectedEwasteType = '';
  int _ewasteQuantity = 0;
  final List<Marker> _ewasteMarkers = [];
  String _additionalNotes = '';

  @override
  void initState() {
    super.initState();
    _getCurrentLocation();
    _loadEwasteLocations();
    _startCompass();
  }

  Future<void> _getCurrentLocation() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      await Geolocator.openLocationSettings();
    }

    LocationPermission permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        _showPermissionDeniedDialog();
        return;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      _showPermissionDeniedForeverDialog();
      return;
    }

    if (permission == LocationPermission.whileInUse || permission == LocationPermission.always) {
      Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
      setState(() {
        _currentLocation = LatLng(position.latitude, position.longitude);
        _mapController.move(_currentLocation!, 15.0); // Zoom woom
        _markers.add(_buildTrackingMarker());
      });
    }
  }

  void _startCompass() {
    FlutterCompass.events?.listen((CompassEvent event) {
      setState(() {
        _deviceHeading = event.heading ?? 0.0;
      });
    });
  }

  Marker _buildTrackingMarker() {
    return Marker(
      point: _currentLocation!,
      builder: (ctx) => _isNavigating
          ? Transform.rotate(
              angle: _deviceHeading * math.pi / 180,
              child: const Icon(
                Icons.navigation,
                color: Colors.blue,
                size: 32,
              ),
            )
          : const Icon(
              Icons.circle,
              color: Colors.blue,
              size: 16,
            ),
    );
  }

  void _loadEwasteLocations() {
    setState(() {
      _markers.clear();
      for (int i = 0; i < ewasteLocations.length; i++) {
        _markers.add(
          Marker(
            point: ewasteLocations[i],
            builder: (ctx) => GestureDetector(
              onTap: () {
                setState(() {
                  _selectedLocation = ewasteLocations[i];
                });
                _showPopup(i);
              },
              child: const Icon(Icons.recycling, color: Colors.green, size: 32),
            ),
          ),
        );
      }
    });
  }

void _showPopup(int index) {
  showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        backgroundColor: Colors.green[50], 
        elevation: 10, 
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20), 
        ),
        title: Text(
          ewasteNames[index],
          style: TextStyle(
            color: Colors.green[800], 
            fontWeight: FontWeight.bold,
            letterSpacing: 0.5, 
          ),
        ),
        content: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(15), 
            boxShadow: [
              BoxShadow(
                color: Colors.green.withOpacity(0.2), 
                spreadRadius: 3,
                blurRadius: 8,
                offset: const Offset(0, 4) 
              ),
            ],
          ),
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Contact: ${ewasteContacts[index]}',
                style: TextStyle(
                  color: Colors.green[700],
                  fontSize: 16,
                  fontWeight: FontWeight.w500, 
                ),
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildActionButton(
                    icon: Icons.phone,
                    color: Colors.green,
                    onPressed: () async {
                      final phoneUrl = 'tel:${ewasteContacts[index]}';
                      if (await canLaunch(phoneUrl)) {
                        await launch(phoneUrl);
                      } else {
                        _showErrorSnackbar('Could not launch the dialer');
                      }
                    },
                  ),
                  _buildActionButton(
                    icon: Icons.directions,
                    color: Colors.green[700]!,
                    onPressed: () async {
                      await _getDirections(index);
                      Navigator.pop(context);
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      );
    },
  );
}

Widget _buildActionButton({
  required IconData icon,
  required Color color,
  required VoidCallback onPressed,
}) {
  return Container(
    decoration: BoxDecoration(
      color: color.withOpacity(0.1),
      borderRadius: BorderRadius.circular(10),
    ),
    child: IconButton(
      icon: Icon(icon, color: color, size: 30),
      onPressed: onPressed,
      padding: const EdgeInsets.all(12),
    ),
  );
}


void _showErrorSnackbar(String message) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(message),
      backgroundColor: Colors.red[400],
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
    ),
  );
}
  Future<void> _getDirections(int index) async {
    setState(() {
      _isLoading = true;
      _isNavigating = true;
      _isEyeIconVisible = true;
      _isSearchIconVisible = false;  // Hide ehhh
    });

    final origin = _currentLocation;
    final destination = ewasteLocations[index];

    if (origin != null) {
      final url =
          'https://api.openrouteservice.org/v2/directions/driving-car?api_key=5b3ce3597851110001cf624882131caf0e3b4895bfd71f743d0468f1&start=${origin.longitude},${origin.latitude}&end=${destination.longitude},${destination.latitude}';

      try {
        final response = await http.get(Uri.parse(url));

        if (response.statusCode == 200) {
          final data = json.decode(response.body);
          final coordinates = data['features'][0]['geometry']['coordinates'] as List;
          final path = coordinates.map((coord) => LatLng(coord[1], coord[0])).toList();

          setState(() {
            _routePoints = path;
            _isLoading = false;
          });

          _zoomOutToIncludeBoth(origin, destination);

          Future.delayed(const Duration(seconds: 2), () {
            _animateZoomInToCurrentLocation(origin);
          });
        } else {
          print('Error getting directions: ${response.statusCode}');
          setState(() {
            _isLoading = false;
          });
        }
      } catch (e) {
        print('Error getting directions: $e');
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _zoomOutToIncludeBoth(LatLng origin, LatLng destination) {
    double latMin = math.min(origin.latitude, destination.latitude);
    double latMax = math.max(origin.latitude, destination.latitude);
    double lonMin = math.min(origin.longitude, destination.longitude);
    double lonMax = math.max(origin.longitude, destination.longitude);

    const padding = 0.1;

    final bounds = LatLngBounds(
      LatLng(latMin - padding, lonMin - padding),
      LatLng(latMax + padding, lonMax + padding),
    );

    _mapController.fitBounds(bounds, options: const FitBoundsOptions(padding: EdgeInsets.all(20)));
  }

  void _animateZoomInToCurrentLocation(LatLng origin) {
    _mapController.move(origin, 18.0);  // Mex zwwm
  }

  void _toggleDirectionsView() {
    setState(() {
      _isNavigating = false;
      _routePoints.clear();
      _isEyeIconVisible = false;
      _isSearchIconVisible = true;  
    });
  }
int _totalEwasteQuantity = 0;
 void _showEwasteDetailsDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              backgroundColor: Colors.green[50], 
              title: Text(
                'E-Waste Details',
                style: TextStyle(color: Colors.green[800], fontWeight: FontWeight.bold),
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  
                  Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.green, width: 1.5),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: DropdownButton<String>(
                      isExpanded: true,
                     dropdownColor: Colors.green[200],  
                      underline: Container(), 
                      value: _selectedEwasteType.isEmpty ? null : _selectedEwasteType,
                      hint: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12.0),
                        child: Text(
                          'Select E-Waste Type',
                          style: TextStyle(color: Colors.green[700]),
                        ),
                      ),
                      onChanged: (String? value) {
                        setState(() {
                          _selectedEwasteType = value ?? '';
                        });
                      },
                      items: <String>['IT Devices', 'Large  Appliances', 'Consumer Electronics', 'Small Appliances', 'Lighting Equipment' ]
                          .map<DropdownMenuItem<String>>((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 12.0),
                            child: Text(value),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    decoration: InputDecoration(
                      labelText: 'Quantity',
                      labelStyle: TextStyle(color: Colors.green[800]),
                      border: OutlineInputBorder(
                        borderSide: const BorderSide(color: Colors.green, width: 2),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.green.shade600, width: 2),
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    keyboardType: TextInputType.number,
                    onChanged: (value) {
                      setState(() {
                        _ewasteQuantity = int.tryParse(value) ?? 0;
                      });
                    },
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    decoration: InputDecoration(
                      labelText: 'Additional Notes',
                      labelStyle: TextStyle(color: Colors.green[800]),
                      border: OutlineInputBorder(
                        borderSide: const BorderSide(color: Colors.green, width: 2),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.green.shade600, width: 2),
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    onChanged: (value) {
                      setState(() {
                        _additionalNotes = value;
                      });
                    },
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green[600],
                      padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    onPressed: () {
                      if (_selectedEwasteType.isNotEmpty && _ewasteQuantity > 0) {
                        setState(() {
                          _totalEwasteQuantity += _ewasteQuantity; 
                        });
                        _addEwasteMarker();
                        Navigator.pop(context);
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: const Text('Please fill in all details.'),
                            backgroundColor: Colors.red[400],
                          ),
                        );
                      }
                    },
                    child: const Text(
                      'Submit',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }


 void _addEwasteMarker() {
  Color markerColor;

  if (_totalEwasteQuantity < 5) {
    markerColor = Colors.green; // Less than 5 = Green
  } else if (_totalEwasteQuantity >= 5 && _totalEwasteQuantity <= 20) {
    markerColor = Colors.yellow; // Between 5 and 20 = Yellow
  } else if (_totalEwasteQuantity > 20 && _totalEwasteQuantity <= 50) {
    markerColor = Colors.orange; // Between 20 and 50 = Orange
  } else {
    markerColor = Colors.red; // More than 50 = Red
  }

  
  setState(() {
    _ewasteMarkers.add(
      Marker(
        point: _currentLocation!,
        builder: (ctx) => Icon(
          Icons.delete_forever,
          color: markerColor, 
          size: 32,
        ),
      ),
    );
    _markers.addAll(_ewasteMarkers); 
  });
}


  void _searchEwasteLocations(String query) {
    setState(() {
      _filteredSuggestions = ewasteNames
          .where((name) => name.toLowerCase().contains(query.toLowerCase()))
          .toList();
    });
  }

void _onSuggestionSelected(int index) {
  setState(() {
    _selectedLocation = ewasteLocations[index]; 
  });

  
  _mapController.move(_selectedLocation!, 18.0); 

  
  Future.delayed(const Duration(milliseconds: 500), () {
    _showPopup(index);  
  });

  
  setState(() {
    _isSearchBarVisible = false;
    _isSearchIconVisible = true; 
  });
}


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: null,
      body: Stack(
        children: [
          FlutterMap(
            mapController: _mapController,
            options: MapOptions(
              center: _currentLocation ?? const LatLng(27.7172, 85.3240),
              zoom: 13,
              minZoom: 1.0,
              maxZoom: 18.0,
              onTap: (_, __) {
                FocusScope.of(context).unfocus();
                widget.onLocationSelected(__);
              },
            ),
            children: [
              TileLayer(
                urlTemplate: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
                subdomains: const ['a', 'b', 'c'],
              ),
              MarkerLayer(
                markers: _markers,
              ),
              if (_isNavigating)
                PolylineLayer(
                  polylines: [
                    Polyline(
                      points: _routePoints,
                      strokeWidth: 4.0,
                      color: Colors.blue,
                    ),
                  ],
                ),
            ],
          ),
          if (_isEyeIconVisible)
            Positioned(
              bottom: 80,
              right: 30,
              child: GestureDetector(
                onTap: _toggleDirectionsView,
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.green,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.3),
                        blurRadius: 6,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  padding: const EdgeInsets.all(8),
                  child: const Icon(
                    Icons.remove_red_eye,
                    size: 32,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          if (_isSearchIconVisible && !_isNavigating)
            Positioned(
              bottom: 30,
              right: 30,
              child: GestureDetector(
                onTap: () {
                  setState(() {
                    _isSearchBarVisible = true;
                    _isSearchIconVisible = false;
                  });
                },
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.blue,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.3),
                        blurRadius: 6,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  padding: const EdgeInsets.all(8),
                  child: const Icon(
                    Icons.search,
                    size: 32,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          if (_isSearchBarVisible && !_isNavigating)
            Positioned(
              top: 30,
              left: 10,
              right: 10,
              child: Material(
                elevation: 5,
                color: Colors.white,
                borderRadius: BorderRadius.circular(30),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  child: TextField(
                    controller: _searchController,
                    autofocus: true,
                    onChanged: _searchEwasteLocations,
                    decoration: InputDecoration(
                      hintText: 'Search E-Waste Locations',
                      hintStyle: const TextStyle(color: Colors.grey),
                      border: InputBorder.none,
                      suffixIcon: IconButton(
                        icon: const Icon(Icons.close),
                        onPressed: () {
                          setState(() {
                            _searchController.clear();
                            _filteredSuggestions.clear();
                          });
                        },
                      ),
                    ),
                  ),
                ),
              ),
            ),
          if (_isSearchBarVisible && !_isNavigating && _filteredSuggestions.isNotEmpty)
            Positioned(
              top: 100,
              left: 10,
              right: 10,
              child: Material(
                elevation: 5,
                color: Colors.white,
                child: SizedBox(
                  height: 200,
                  child: ListView.builder(
                    itemCount: _filteredSuggestions.length,
                    itemBuilder: (context, index) {
                      return Container(
                        margin: const EdgeInsets.symmetric(vertical: 5),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.1),
                              blurRadius: 5,
                              spreadRadius: 1,
                            ),
                          ],
                        ),
                        child: ListTile(
                          title: Text(_filteredSuggestions[index]),
                          onTap: () {
                            final selectedIndex = ewasteNames.indexOf(_filteredSuggestions[index]);
                            _onSuggestionSelected(selectedIndex);
                          },
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
          Positioned(
            bottom: 30,
            left: 30,
            child: GestureDetector(
              onTap: _showEwasteDetailsDialog,
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.orange,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.3),
                      blurRadius: 6,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                padding: const EdgeInsets.all(8),
                child: const Icon(
                  Icons.delete_forever,
                  size: 32,
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showPermissionDeniedDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Location Permission Denied'),
          content: const Text('Please enable location permissions to use the app.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }

  void _showPermissionDeniedForeverDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Location Permission Denied Forever'),
          content: const Text('Please enable location permissions in the settings.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }
}
